// BloodTypeAnalysis.java
// A simple program to analyze blood types and give information

import java.util.*;

public class BloodTypeAnalysis {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> bloodInfo = new HashMap<>();

        bloodInfo.put("A+", "Can donate to A+ and AB+. Can receive from A+, A-, O+ and O-.");
        bloodInfo.put("A-", "Can donate to A+, A-, AB+, AB-. Can receive from A- and O-.");
        bloodInfo.put("B+", "Can donate to B+ and AB+. Can receive from B+, B-, O+ and O-.");
        bloodInfo.put("B-", "Can donate to B+, B-, AB+, AB-. Can receive from B- and O-.");
        bloodInfo.put("AB+", "Universal recipient. Can receive from all blood types.");
        bloodInfo.put("AB-", "Can donate to AB+ and AB-. Can receive from AB-, A-, B-, and O-.");
        bloodInfo.put("O+", "Can donate to A+, B+, AB+, and O+. Can receive from O+ and O-.");
        bloodInfo.put("O-", "Universal donor. Can donate to all blood types. Can receive from O-.");

        System.out.print("Enter a blood type (e.g., A+, O-, AB+): ");
        String input = scanner.nextLine().toUpperCase();

        if (bloodInfo.containsKey(input)) {
            System.out.println("Blood Type Info:");
            System.out.println(bloodInfo.get(input));
        } else {
            System.out.println("Invalid blood type entered.");
        }

        scanner.close();
    }
}
